import React from 'react';
import Task from './Task';

function TaskList({ tasks, onComplete, onDelete }) {
  return (
    <div>
      {tasks.map((task) => (
        <Task 
          key={task.id} 
          task={task} 
          onComplete={() => onComplete(task.id)} 
          onDelete={() => onDelete(task.id)} 
        />
      ))}
    </div>
  );
}

export default TaskList;