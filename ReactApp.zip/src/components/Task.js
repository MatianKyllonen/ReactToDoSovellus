import React from 'react';

function Task({ task, onComplete, onDelete }) {
  return (
    <div className={`task ${task.completed ? 'completed' : ''}`}>
      <div className="task-content">
        {task.text}
      </div>
      <div className="task-actions">
        <button onClick={() => onComplete(task.id)}>
          {task.completed ? 'Undo' : 'Complete'}
        </button>
        <button className="delete-button" onClick={() => onDelete(task.id)}>
          Delete
        </button>
      </div>
    </div>
  );
}

export default Task;